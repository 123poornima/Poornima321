package com.niit.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

//replica of table
@Entity
//it is used to represent table name 
@Table(name="category")
//it has to pass atributes(variables)  to DAO
@Component 
public class Category
{
	
	@NotEmpty(message="Please enter ID")
	  private String c_ID;
	 
	@NotEmpty(message="Please enter Name")
	  private String c_Name;
	  
	@NotEmpty(message="Please enter Description")   
	  private String c_Description;
	  
	  private Set<Product> products;
	
	 //refers to primary key automatically
	  @Id
	  public String getC_ID() 
	  {
		return c_ID;
	  }

	public String getC_Name()
	{
		return c_Name;
	}

	public String getC_Description()
	{
		return c_Description;
	}

	public void setC_ID(String c_ID)
	{
		this.c_ID = c_ID;
	}

	public void setC_Name(String c_Name) 
	{
		this.c_Name = c_Name;
	}

	public void setC_Description(String c_Description) 
	{
		this.c_Description = c_Description;
	}
	
	


	  @OneToMany(mappedBy="category",fetch=FetchType.EAGER)
		public Set<Product> getProducts() {
			return products;
		}

		public void setProducts(Set<Product> products) {
			this.products = products;
		}
	 


}
