package com.niit.test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.SupplierDAO;

import com.niit.model.Supplier;

public class SupplierTest {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		SupplierDAO supplierDAO= (SupplierDAO) context.getBean("supplierDAO");

		Supplier supplier=(Supplier) context.getBean("supplier");
		
		
		supplier.setS_ID("242");
		supplier.setS_Name("po");
	
		supplier.setS_Address("DVG");
		supplier.setS_Phoneno("88676757");
		
		supplierDAO.addSupplier(supplier);
		
		

	}

}
