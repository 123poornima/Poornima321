package com.niit.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.User;

//
@EnableTransactionManagement

//to connect to database by taking all attributes from pojo class
@Repository("userDAO")
public class UserDAOImpl implements UserDAO
{
	
	//it will create an object without the help of new operator 	
   @Autowired    
   private SessionFactory sessionfactory;
   
   public UserDAOImpl(SessionFactory sessionfactory)
   {
	   this.sessionfactory=sessionfactory;
   }
   
   //used for transaction from model to DAO class
   @Transactional
   public void addUser(User user)
   {
	  sessionfactory.getCurrentSession().saveOrUpdate(user);
   }
  
}
